
public class Prjct5_03_Driver {
	public static void main(String args[]) {
		Prjct5_03_Task obj1 = new Prjct5_03_Task();
		Prjct5_03_Task obj2 = new Prjct5_03_Task();
		Prjct5_03_Task obj3 = new Prjct5_03_Task();
		Prjct5_03_Task obj4 = new Prjct5_03_Task();
		Prjct5_03_Task obj5 = new Prjct5_03_Task();
		
		System.out.println(obj1.getPriority());
		System.out.println(obj2.getPriority());
		System.out.println(obj3.getPriority());
		System.out.println(obj4.getPriority());
		System.out.println(obj5.getPriority());
	}
}
