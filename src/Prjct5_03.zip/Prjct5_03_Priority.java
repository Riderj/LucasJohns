
public interface Prjct5_03_Priority {
	void setPriority(int value);
	int getPriority();
}
