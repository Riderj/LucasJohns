import java.util.Scanner;


public class Prjct5_06 implements Prjct5_06_Lockable {
	private  int key = -1;
	private static boolean isLocked = false;
	private int attempts=4;
	private static String choice;
	
	public static void main(String[] args) {
		System.out.println("Welcome to Locks, please proceed through the setup process by entering a key to set as your lock passcode:");
		Prjct5_06 lock = new Prjct5_06();
		Scanner scan = new Scanner(System.in);
		lock.setKey(scan.nextInt());
		menuDisplay();
		
		choice = scan.next();
		while (!choice.equalsIgnoreCase("Exit")) {
			if(choice.equalsIgnoreCase("Locked")) {
				String status = isLocked == false ? "Unlocked" : "Locked";
				System.out.println("Your lock is "+status);
			}else if(choice.equalsIgnoreCase("Lock")) {
				System.out.println("Please enter your security key:");
				int sKey = scan.nextInt();
				lock.lock(sKey);
			}else if(choice.equalsIgnoreCase("Unlock")) {
				System.out.println("Please enter your security key:");
				int sKey = scan.nextInt();
				lock.unlock(sKey);
			}
			long start = System.currentTimeMillis();
			while(System.currentTimeMillis()-start < 1000) {}

			menuDisplay();
			choice = scan.next();
		}
	}
	private static void menuDisplay() {
		System.out.println("\t=====================Locks Main Menu============================");
		System.out.println("Type one of the following:");
		System.out.println();
		System.out.println("\t\t\t\t\t\t\tLocked");
		System.out.println();
		System.out.println("\t\t\t\t\t\t\tLock");
		System.out.println();
		System.out.println("\t\t\t\t\t\t\tUnlock");
		System.out.println();
		System.out.println("\t\t\t\t\t\t\tExit");
		
	}
	public void setKey(int key) {
			this.key = key;
	}
	public void lock(int key) {
		if(!isLocked) {
			if(key == this.key) {
				isLocked = true;
				System.out.println("The key was entered successful, it is now locked.");
				attempts = 4;
			}else {
				if(attempts != 0) {
					attempts--;
					System.out.println("That is the wrong key, you have "+attempts+" more attempts");
				}else {
					System.out.println("You've entered an invalid key more than 3 times, this session will be terminated.");
				}
			}
		}else {
			System.out.println("That lock is already locked.");
		}
	}
	public void unlock(int key) {
		if(isLocked) {
			if(key == this.key) {
				isLocked = false;
				System.out.println("The key was entered successful, it is now unlocked.");
				attempts = 4;
			}else {
				if(attempts != 0) {
					attempts--;
					System.out.println("That is the wrong key, you have "+attempts+" more attempts");
				}else {
					System.out.println("You've entered an invalid key more than 3 times, this session will be terminated.");
				}
			}
		}else {
			System.out.println("That lock is already unlocked.");
		}
	}
	public boolean locked() {
		return isLocked;
	}
}
