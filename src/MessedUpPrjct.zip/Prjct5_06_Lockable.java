
public interface Prjct5_06_Lockable {
	void setKey(int key);
	void lock(int key);
	void unlock(int key);
	boolean locked();
}
