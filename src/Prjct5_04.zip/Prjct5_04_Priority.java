
public interface Prjct5_04_Priority {
	void setPriority(int value);
	int getPriority();
}
