
public interface Prjct5_04_Complexity {
	void setComplexity (int complexity);
	int getComplexity();
}
