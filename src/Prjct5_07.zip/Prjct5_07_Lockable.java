
public interface Prjct5_07_Lockable {
	boolean Locked();
	void setLock(int key);
	void lock(int key);
	void unlock(int key);
}
