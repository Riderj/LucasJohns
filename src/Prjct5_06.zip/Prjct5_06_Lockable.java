
public interface Prjct5_06_Lockable {
	boolean Locked();
	void setLock(int key);
	void lock(int key);
	void unlock(int key);
}
