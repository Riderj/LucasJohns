
public interface Prjct5_05_Priority {
	void setPriority(int value);
	int getPriority();
}
