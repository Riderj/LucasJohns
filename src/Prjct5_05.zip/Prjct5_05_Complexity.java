
public interface Prjct5_05_Complexity {
	void setComplexity (int complexity);
	int getComplexity();
}
